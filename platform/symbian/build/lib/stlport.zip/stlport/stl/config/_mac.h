#define _STLP_PLATFORM "Mac"
