#ifndef _STLP_WINSCW_H
#define _STLP_WINSCW_H

#define _STLP_COMPILER "WINSCW"

#undef __MWERKS__

//======================================================================

#define _STLP_HAS_SPECIFIC_PROLOG_EPILOG    1
#define _STLP_WCHAR_T_IS_USHORT             1
#define _STLP_LONG_LONG                     long long
#define _STLP_USE_MALLOC                    1
#define _STLP_NO_BAD_ALLOC                  1

//======================================================================

#endif
